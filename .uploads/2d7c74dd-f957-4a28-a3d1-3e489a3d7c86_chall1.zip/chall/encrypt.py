#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from secret import TAPS, SEED

BITS_PER_BYTE = 8


def keystream(nbytes):
    s = SEED
    out = bytearray()
    for _ in range(nbytes):
        byte = 0
        for _ in range(BITS_PER_BYTE):
            byte = (byte << 1) | (s & 1)          # MSB-first 打包
            fb = bin(s & TAPS).count("1") & 1     # parity(state & TAPS)
            s = (s >> 1) | (fb << 63)
        out.append(byte)
    return bytes(out)


def crypt(data):
    return bytes(a ^ b for a, b in zip(data, keystream(len(data))))


def main():
    flag = open("flag.mp3", "rb").read()
    known = open("known.txt", "rb").read()

    open("flag.enc", "wb").write(crypt(flag))
    open("known.enc", "wb").write(crypt(known))

    print(f"[+] flag.mp3  {len(flag)} B -> flag.enc")
    print(f"[+] known.txt {len(known)} B -> known.enc")


if __name__ == "__main__":
    main()
