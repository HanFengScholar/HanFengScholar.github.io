from Crypto.Util.number import *
from math import prod
from random import sample, randint
from secret import flag

primes = []
for x in range(2, 8000):
    if all(x % p for p in range(2, int(x ** 0.5) + 1)):
        primes.append(x)

R = getPrime(400)
while True:
    S = 2 * prod(sample(primes[1:], 56))
    p = S * R + 1
    if isPrime(p):
        break

q = getStrongPrime(1024)
n = p * q

e = getPrime(32)
while GCD(e, (p - 1) * (q - 1)) != 1:
    e = getPrime(32)
c = pow(bytes_to_long(flag), e, n)

dr = pow(e, -1, R)
Q = e * dr - 1

k = randint(7000, 9000)
h = 2**k + randint(3, 9) * k**6

r = getPrime(1023)
L = Q * h + r**2

print(f'{n = }')
print(f'{e = }')
print(f'{c = }')
print(f'{L = }')
