#!/usr/bin/env sage
"""Organizer-side generator for the SageMath training CTF challenge.
Run: sage chall_sage_v2.sage --flag-file flag.txt --out data_v2.json
Publish this source (without flag.txt) and the generated data_v2.json.
"""
import argparse
import hashlib
import json
import random
import re
import secrets
from pathlib import Path
from sage.all import GF, PolynomialRing

P = 65537
N = 48
WIDTH = 2*N
EXT = 48

def as_list(v, n=WIDTH):
    return [int(v[i]) for i in range(n)]

def cover(vals, secret, label):
    """Additive mask, field coefficients in [0, P), independent per list."""
    seed = int(secret).to_bytes(6, 'big')
    stream = hashlib.shake_256(b'SYC-SAGE-V2|' + label.encode() + b'|' + seed)
    buf = stream.digest(4 * len(vals))
    masks = [int.from_bytes(buf[4*i:4*i+4], 'big') % P for i in range(len(vals))]
    return [int((int(c) + m) % P) for c,m in zip(vals, masks)]

def make(flag, seed=None):
    if not re.fullmatch(rb'syc\{[A-Za-z0-9_]+\}', flag) or len(flag)>80:
        raise ValueError('Expected syc{...} of length <= 80')
    rng = random.Random(seed) if seed is not None else secrets.SystemRandom()
    R = PolynomialRing(GF(P), 'x')
    def poly():
        return R([rng.randrange(P) for _ in range(WIDTH)])
    def irreducible(exclude=None):
        for _ in range(4096):
            z = R([rng.randrange(P) for _ in range(N)]+[1])
            if z != exclude and z.is_irreducible():
                return z
        raise RuntimeError('Failed sampling irreducible polynomial')
    f = irreducible(); g = irreducible(f); H = f*g
    for _ in range(256):
        K = poly()
        if K.gcd(H) == 1:
            break
    else:
        raise RuntimeError('Could not sample unit K')
    O, p0 = poly(), poly()
    inputs = [p0, (p0+f)%H, (p0+g)%H]
    outputs = [(K*v+O)%H for v in inputs]
    message = R(list(flag) + [rng.randrange(256) for _ in range(WIDTH-len(flag))])
    C = (K*message+O)%H

    # Encode coefficients as bits; include the modulus to fix the field model.
    E = GF(2**EXT, 'z')
    a = E.multiplicative_generator()
    order = 2**EXT-1
    s = rng.randrange(1, order)
    b = a**s
    assert a.multiplicative_order() == order
    payload = {
        'name': 'Ech...ooo',
        'p': int(P), 'width': int(WIDTH), 'length': len(flag),
        'extension_degree': int(EXT),
        'extension_modulus': [int(c) for c in E.modulus().list()],
        'generator': int(sum(int(c) << i for i,c in enumerate(a.polynomial().list()))),
        'challenge': int(sum(int(c) << i for i,c in enumerate(b.polynomial().list()))),
        'f': as_list(f, N+1), 'g': as_list(g, N+1),
        'calibration_inputs': [as_list(v) for v in inputs],
        'calibration_outputs_masked': [cover(as_list(v), s, 'cal-%d'%i) for i,v in enumerate(outputs)],
        'ciphertext_masked': cover(as_list(C), s, 'cipher'),
    }
    return payload

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--flag-file', type=Path, default=Path('flag.txt'))
    ap.add_argument('--out', type=Path, default=Path('data_v2.json'))
    ap.add_argument('--seed', type=int, help='Development only; do NOT use for contest release')
    args=ap.parse_args()
    data=make(args.flag_file.read_bytes().strip(),args.seed)
    args.out.write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
    print('[+] generated',args.out)

if __name__=='__main__':
    main()
