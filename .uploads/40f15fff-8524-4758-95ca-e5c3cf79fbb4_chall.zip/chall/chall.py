#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
import random
import re
import secrets
import sys

P = 257

def seal(message, key):
    if len(message) != len(key) or len(key) % 2 != 1:
        raise ValueError("an odd tape and equally long key are required")
    ciphertext = [(m + k) % P for m, k in zip(message, key)]
    receipt = [(key[i] + key[(i + 1) % len(key)]) % P
               for i in range(len(key))]
    return ciphertext, receipt



def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--flag-file", type=Path, default=Path(__file__).resolve().with_name("flag.txt"))
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().with_name("data"))
    ap.add_argument("--seed", type=int, help="private reproducibility input for testing only")
    args = ap.parse_args()
    secret = args.flag_file.read_bytes().rstrip(b"\r\n")
    if not re.fullmatch(rb"syc\{[a-z0-9_]+\}", secret) or len(secret) > 64:
        ap.error("flag must be lowercase syc{...}, at most 64 ASCII bytes")
    rng = random.Random(args.seed) if args.seed is not None else secrets.SystemRandom()
    n = 65
    message = list(secret) + [rng.randrange(256) for _ in range(n - len(secret))]
    key = [rng.randrange(P) for _ in range(n)]
    c, a = seal(message, key)
    data = {"p": P, "n": n, "length": len(secret), "ciphertext": c, "receipt": a}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print("[+] public instance written:", args.out)


if __name__ == "__main__":
    main()
