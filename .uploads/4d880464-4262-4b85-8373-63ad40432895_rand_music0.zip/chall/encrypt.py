#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
encrypt.py —— 题目用的加密脚本

用法:  python3 encrypt.py

行为:
    flag.mp3   --(crypt)-->  flag.enc
    known.txt  --(crypt)-->  known.enc

算法:
    文件按 32 字节一帧；每帧 32 字节密钥流来自一个线性同余发生器
        s <- (A * s + C) mod M        （每产生一个 32-bit 字递推一次）
    一帧消耗 8 个连续输出（8 * 4 = 32 字节），帧内字节再按 PERM 置换:
        ks[frame*32 + i] = frame_bytes[PERM[i]]

    加解密是同一个操作（逐字节 XOR）。
"""
from secret import M, A, C, seed

FRAME_BYTES = 32
FRAME_WORDS = FRAME_BYTES // 4          # = 8

# 帧内字节置换
PERM = [23, 18, 30, 31, 5, 24, 10, 12,
        20, 11, 9, 26, 6, 22, 3, 13,
        28, 14, 1, 8, 29, 25, 27, 19,
        15, 7, 21, 2, 0, 16, 17, 4]


def keystream(nbytes):
    out = bytearray()
    s = seed
    while len(out) < nbytes:
        frame = bytearray()
        for _ in range(FRAME_WORDS):
            s = (A * s + C) % M
            frame += s.to_bytes(4, "big")
        out += bytes(frame[PERM[i]] for i in range(FRAME_BYTES))
    return bytes(out[:nbytes])


def crypt(data):
    return bytes(a ^ b for a, b in zip(data, keystream(len(data))))


def main():
    flag = open("flag.mp3", "rb").read()
    known = open("known.txt", "rb").read()

    open("flag.enc", "wb").write(crypt(flag))
    open("known.enc", "wb").write(crypt(known))

    print(f"[+] flag.mp3  {len(flag)} B -> flag.enc")
    print(f"[+] known.txt {len(known)} B -> known.enc")


if __name__ == "__main__":
    main()
