from decimal import Decimal, getcontext
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad
from Crypto.Util.number import *
from hashlib import sha256
from secrets import randbits
from math import gcd
from secret import flag
getcontext().prec = 400

p = getPrime(512)
while p % 4 != 3:
    p = getPrime(512)
while True:
    a = randbits(236) | (1 << 235) | 1
    b = randbits(100) | (1 << 99) | 1
    if gcd(a, b) == 1:
        break
scale = randbits(384) | (1 << 383) | 1
a *= scale
b *= scale
hint = (a * b) % p
N = a * a + 2 * b
leak = f"{Decimal(N).sqrt() - a:.156f}"

key = sha256(f"{a}:{b}".encode()).digest()
iv = get_random_bytes(16)
cipher = AES.new(key, AES.MODE_CBC, iv=iv)
ct = cipher.encrypt(pad(flag, 16))

print(f'{leak = }')
print(f'{p = }')
print(f'{hint = }')
print(f'{iv = }')
print(f'{ct = }')
